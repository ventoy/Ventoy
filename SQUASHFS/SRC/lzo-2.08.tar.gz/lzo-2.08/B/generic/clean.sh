#! /bin/sh
# vi:ts=4:et
# Copyright (C) 1996-2014 Markus F.X.J. Oberhumer

rm -f *.o liblzo2.a dict.out lzopack.out precomp.out precomp2.out simple.out lzotest.out testmini.out

true
